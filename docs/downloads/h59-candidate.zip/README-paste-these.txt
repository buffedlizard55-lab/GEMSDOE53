Paste-ready DrivenData fields for this artifact (competition 306, 'Make a
submission' dialog). The status line is part of the record: do not spend a
weekly slot unless evidence/h59_slot_gate.json says slot_bar_met=true.
